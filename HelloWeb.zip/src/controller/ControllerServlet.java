package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet(name = "ControllerServlet", loadOnStartup = 1, urlPatterns = {
		"/hero", "/addToCart", "/viewCart", "/heroine", "/home", "/aboutus", "/contactus", "/gallery",
        "/feedback", "/purchase", "/success","/test" })
 
	public class ControllerServlet extends HttpServlet {
	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {

	        String userPath = request.getServletPath();

	        String url = "/WEB-INF/view" + userPath + ".jsp";
	        // if category page is requested
	        if (userPath.equals("/hero")) {
	            // TODO: Implement category request
	        	try {
	        		request.getRequestDispatcher("hero.jsp").forward(request, response);
	        	} catch (Exception ex) {
	        		ex.printStackTrace();
	        	}

	        // if cart page is requested
	        }
	        
	        else if (userPath.equals("/home")) {
	        	try {
	        		request.getRequestDispatcher("home.jsp").forward(request, response);
	        	} catch (Exception ex) {
	        		ex.printStackTrace();
	        	}

	        // if cart page is requested
	        }
	        else if (userPath.equals("/heroine")) {
	            // TODO: Implement cart page request

	        	try {
	        		request.getRequestDispatcher("heroine.jsp").forward(request, response);
	        	} catch (Exception ex) {
	        		ex.printStackTrace();
	        	}	        // if checkout page is requested
	        } 
	        
	        else if (userPath.equals("/test")) {
	            // TODO: Implement cart page request
	        	String[] vehicle;

	        	try {
	        		request.getRequestDispatcher(url).forward(request, response);
	        	} catch (Exception ex) {
	        		ex.printStackTrace();
	        	}	        // if checkout page is requested
	        } 
	        // use RequestDispatcher to forward request internally

	    }
 
	   
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {

	        String userPath = request.getServletPath();

	        // if addToCart action is called
	        if (userPath.equals("/purchase")) {
	         System.out.println("I am hero");
	         String name= request.getParameter("name");
	         String age = request.getParameter("age");
	         String email = request.getParameter("email");	      
	         System.out.println("Name :  "+ name  + "    " +"aGE : " + age );
	         
	         request.setAttribute("mancheKoName", name);
	         request.setAttribute("mancheKoAge", age);
	         request.setAttribute("mancheKoemail", email);

	         request.getRequestDispatcher("success.jsp").forward(request, response);

	        // if updateCart action is called
	        } else if (userPath.equals("/updateCart")) {
	            // TODO: Implement update cart action

	        // if purchase action is called
	        }  

	        // use RequestDispatcher to forward request internally
	        String url = "/WEB-INF/view" + userPath + ".jsp";

	      
	    }

	}

 
